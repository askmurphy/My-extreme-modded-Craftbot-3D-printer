var searchData=
[
  ['gconf_5ft_497',['GCONF_t',['../struct_g_c_o_n_f__t.html',1,'GCONF_t'],['../struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html',1,'TMC2208_n::GCONF_t']]],
  ['global_5fscaler_5ft_498',['GLOBAL_SCALER_t',['../struct_g_l_o_b_a_l___s_c_a_l_e_r__t.html',1,'']]],
  ['gstat_5ft_499',['GSTAT_t',['../struct_g_s_t_a_t__t.html',1,'']]]
];
