var namespace_t_m_c2208__n =
[
    [ "CHOPCONF_t", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t" ],
    [ "DRV_STATUS_t", "struct_t_m_c2208__n_1_1_d_r_v___s_t_a_t_u_s__t.html", "struct_t_m_c2208__n_1_1_d_r_v___s_t_a_t_u_s__t" ],
    [ "GCONF_t", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t" ],
    [ "IOIN_t", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html", "struct_t_m_c2208__n_1_1_i_o_i_n__t" ],
    [ "PWM_SCALE_t", "struct_t_m_c2208__n_1_1_p_w_m___s_c_a_l_e__t.html", "struct_t_m_c2208__n_1_1_p_w_m___s_c_a_l_e__t" ],
    [ "PWMCONF_t", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t" ],
    [ "VACTUAL_t", "struct_t_m_c2208__n_1_1_v_a_c_t_u_a_l__t.html", "struct_t_m_c2208__n_1_1_v_a_c_t_u_a_l__t" ]
];