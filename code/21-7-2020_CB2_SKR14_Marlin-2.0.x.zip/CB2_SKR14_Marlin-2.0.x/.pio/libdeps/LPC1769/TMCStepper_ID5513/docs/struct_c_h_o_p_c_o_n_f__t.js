var struct_c_h_o_p_c_o_n_f__t =
[
    [ "__pad0__", "struct_c_h_o_p_c_o_n_f__t.html#a330fbc9bc8b75ec96ebb3a12fc19264e", null ],
    [ "__pad1__", "struct_c_h_o_p_c_o_n_f__t.html#ae34adfef44e892d2824cf27c3ecf3312", null ],
    [ "chm", "struct_c_h_o_p_c_o_n_f__t.html#aa775b2014855ebd832a16615e65e1cd8", null ],
    [ "dedge", "struct_c_h_o_p_c_o_n_f__t.html#ae99a0581b6487aa70263a7047a68916b", null ],
    [ "disfdcc", "struct_c_h_o_p_c_o_n_f__t.html#acb365618808a2cd3c49c74987d74fd64", null ],
    [ "diss2g", "struct_c_h_o_p_c_o_n_f__t.html#a95c9ecfa7c3d93aa3ab080754bdc1fbc", null ],
    [ "diss2vs", "struct_c_h_o_p_c_o_n_f__t.html#aabb5f5ed485819288e5d416d17fc82d5", null ],
    [ "hend", "struct_c_h_o_p_c_o_n_f__t.html#a397c6f3fa2c84bc16faadf4f13195229", null ],
    [ "hstrt", "struct_c_h_o_p_c_o_n_f__t.html#a9caa4ba6092bab3da43ba141ae85b92f", null ],
    [ "intpol", "struct_c_h_o_p_c_o_n_f__t.html#a732d965d87ab7e2db879c50d6e4c2d55", null ],
    [ "mres", "struct_c_h_o_p_c_o_n_f__t.html#a31c4fcbda9796af6f7b63d0cdd9ac299", null ],
    [ "rndtf", "struct_c_h_o_p_c_o_n_f__t.html#a9e11c7eb057974d7df09835650f77323", null ],
    [ "sr", "struct_c_h_o_p_c_o_n_f__t.html#a9437c0740e43ac06de32469202578bd8", null ],
    [ "sync", "struct_c_h_o_p_c_o_n_f__t.html#a3b6ee8a79ec7aca47ca52b04fc048770", null ],
    [ "tbl", "struct_c_h_o_p_c_o_n_f__t.html#ac1bff57a2396fc8684e15ccd6c7e198f", null ],
    [ "toff", "struct_c_h_o_p_c_o_n_f__t.html#a844f7e562bacf2b0c3a47f019fd0391a", null ],
    [ "tpfd", "struct_c_h_o_p_c_o_n_f__t.html#aecfb90627b1a7b62938e1d747d6c75aa", null ],
    [ "vhighchm", "struct_c_h_o_p_c_o_n_f__t.html#aeae8cb673fd229f675b0a5bdb8a23be7", null ],
    [ "vhighfs", "struct_c_h_o_p_c_o_n_f__t.html#ac1ab341ecfa4debcc3dc10b040dc5d1f", null ],
    [ "vsense", "struct_c_h_o_p_c_o_n_f__t.html#a48d6b51e858ab407ff762c1c7c7dfb61", null ]
];